Hologram asset extraction report

The APK stores the hologram resources inside Unity asset bundles rather than as standalone named image files.
Bundles containing Hologram references:
- assets/GS : 4175969 bytes, 2 textual Hologram references
- assets/HS : 1115257 bytes, 8 textual Hologram references
- assets/OGE : 285777 bytes, 2 textual Hologram references
- assets/OGG : 1030685 bytes, 1 textual Hologram references

Known references include:
- BRMobile/ArtVFX/Hologram
- assets/resources/shaders/brmobile/special/hologram.shader
